using SQLApp.Model;

namespace SQLApp.ModelView
{
    public class CProdutoService
    {
        // ---------------- VALIDAÇÕES (back-end) ----------------

        private void Validar(CProduto p)
        {
            if (p == null)
                throw new CValidacaoException("Produto inválido.");

            p.NomeProduto = (p.NomeProduto ?? string.Empty).Trim();
            p.Tipo = (p.Tipo ?? string.Empty).Trim();

            if (string.IsNullOrWhiteSpace(p.NomeProduto))
                throw new CValidacaoException("O nome do produto é obrigatório.");

            if (p.NomeProduto.Length > 50)
                throw new CValidacaoException("O nome do produto deve ter no máximo 50 caracteres.");

            if (string.IsNullOrWhiteSpace(p.Tipo))
                throw new CValidacaoException("O tipo do produto é obrigatório.");

            if (p.Tipo.Length > 50)
                throw new CValidacaoException("O tipo do produto deve ter no máximo 50 caracteres.");

            if (p.Preco <= 0)
                throw new CValidacaoException("O preço deve ser maior que zero.");

            if (p.Preco > 1000000)
                throw new CValidacaoException("O preço não pode passar de R$ 1.000.000,00.");

            if (decimal.Round(p.Preco, 2) != p.Preco)
                throw new CValidacaoException("O preço deve ter no máximo 2 casas decimais.");

            if (p.QtdEstoque < 0)
                throw new CValidacaoException("A quantidade em estoque não pode ser negativa.");
        }

        private async Task<CProduto> GarantirExiste(int codigo)
        {
            if (codigo <= 0)
                throw new CValidacaoException("Código do produto inválido.");

            var db = await CDatabase.GetConexao();
            var p = await db.FindAsync<CProduto>(codigo);

            if (p == null)
                throw new CValidacaoException($"Produto {codigo} não encontrado.");

            return p;
        }

        // ---------------- CRUD ----------------

        // CREATE
        public async Task<int> InsertProduto(CProduto p)
        {
            p.CodigoProduto = 0;
            Validar(p);

            var db = await CDatabase.GetConexao();
            return await db.InsertAsync(p);
        }

        // UPDATE
        public async Task<int> UpdateProduto(CProduto p)
        {
            await GarantirExiste(p.CodigoProduto);
            Validar(p);

            var db = await CDatabase.GetConexao();
            return await db.UpdateAsync(p);
        }

        // DELETE
        public async Task<int> DeleteProduto(int codigo)
        {
            await GarantirExiste(codigo);

            var db = await CDatabase.GetConexao();

            // Integridade referencial: não exclui produto usado em alguma compra
            int itens = await db.Table<CItemCompra>()
                .Where(x => x.CodigoProduto == codigo)
                .CountAsync();

            if (itens > 0)
                throw new CValidacaoException(
                    $"Não é possível excluir: o produto está em {itens} item(ns) de compra.");

            return await db.DeleteAsync<CProduto>(codigo);
        }

        // READ - todos
        public async Task<List<CProduto>> GetProdutos()
        {
            var db = await CDatabase.GetConexao();
            return await db.Table<CProduto>().OrderBy(x => x.NomeProduto).ToListAsync();
        }

        // READ - por código
        public async Task<CProduto?> GetProduto(int codigo)
        {
            if (codigo <= 0)
                return null;

            var db = await CDatabase.GetConexao();
            return await db.FindAsync<CProduto>(codigo);
        }

        // READ - busca por nome ou tipo (SearchBar)
        public async Task<List<CProduto>> ConsultarNome(string? texto)
        {
            var db = await CDatabase.GetConexao();
            texto = (texto ?? string.Empty).Trim();

            if (texto.Length == 0)
                return await GetProdutos();

            // Consulta parametrizada (evita SQL Injection) e sem diferenciar maiúsculas/minúsculas
            return await db.QueryAsync<CProduto>(
                "SELECT * FROM Produto WHERE NomeProduto LIKE ? OR Tipo LIKE ? ORDER BY NomeProduto",
                $"%{texto}%", $"%{texto}%");
        }
    }
}
