using SQLite;
using SQLApp.Model;

namespace SQLApp.ModelView
{
    // Conexão única com o banco de dados, compartilhada por todos os Services
    public static class CDatabase
    {
        // Nome do arquivo do banco de dados SQLite
        private const string DatabaseFilename = "loja.db3";

        // Flags do SQLite: leitura/escrita, cria se não existir e cache compartilhado
        private const SQLiteOpenFlags Flags =
            SQLiteOpenFlags.ReadWrite |
            SQLiteOpenFlags.Create |
            SQLiteOpenFlags.SharedCache;

        private static SQLiteAsyncConnection? _db;

        // Garante que só uma tela inicialize o banco por vez
        private static readonly SemaphoreSlim _trava = new SemaphoreSlim(1, 1);

        public static async Task<SQLiteAsyncConnection> GetConexao()
        {
            // Se a conexão já foi inicializada, apenas retorna
            if (_db != null)
                return _db;

            await _trava.WaitAsync();
            try
            {
                if (_db == null)
                {
                    string caminho = Path.Combine(FileSystem.AppDataDirectory, DatabaseFilename);

                    var db = new SQLiteAsyncConnection(caminho, Flags);

                    // Cria as 4 tabelas do modelo lógico
                    await db.CreateTableAsync<CCliente>();
                    await db.CreateTableAsync<CProduto>();
                    await db.CreateTableAsync<CCompra>();
                    await db.CreateTableAsync<CItemCompra>();

                    _db = db;
                }
            }
            finally
            {
                _trava.Release();
            }

            return _db;
        }
    }

    // Exceção usada pelas validações do back-end
    public class CValidacaoException : Exception
    {
        public CValidacaoException(string mensagem) : base(mensagem) { }
    }
}
