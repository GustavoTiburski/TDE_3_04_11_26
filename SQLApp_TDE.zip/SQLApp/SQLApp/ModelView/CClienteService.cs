using System.Text.RegularExpressions;
using SQLApp.Model;

namespace SQLApp.ModelView
{
    public class CClienteService
    {
        // ---------------- VALIDAÇÕES (back-end) ----------------

        private async Task Validar(CCliente c)
        {
            if (c == null)
                throw new CValidacaoException("Cliente inválido.");

            c.Nome = (c.Nome ?? string.Empty).Trim();
            c.Telefone = (c.Telefone ?? string.Empty).Trim();

            if (string.IsNullOrWhiteSpace(c.Nome))
                throw new CValidacaoException("O nome do cliente é obrigatório.");

            if (c.Nome.Length < 3)
                throw new CValidacaoException("O nome do cliente deve ter pelo menos 3 caracteres.");

            if (c.Nome.Length > 50)
                throw new CValidacaoException("O nome do cliente deve ter no máximo 50 caracteres.");

            if (c.RG <= 0)
                throw new CValidacaoException("O RG é obrigatório e deve ser um número positivo.");

            if (c.RG > 9999999999)
                throw new CValidacaoException("O RG deve ter no máximo 10 dígitos.");

            if (string.IsNullOrWhiteSpace(c.Telefone))
                throw new CValidacaoException("O telefone é obrigatório.");

            if (c.Telefone.Length > 14)
                throw new CValidacaoException("O telefone deve ter no máximo 14 caracteres. Ex: (54)99999-9999");

            // Só aceita dígitos, parênteses, hífen e espaço
            if (!Regex.IsMatch(c.Telefone, @"^[0-9()\-\s]+$"))
                throw new CValidacaoException("O telefone só pode conter números, parênteses, hífen e espaço.");

            int digitos = c.Telefone.Count(char.IsDigit);
            if (digitos < 10 || digitos > 11)
                throw new CValidacaoException("O telefone deve ter DDD + número (10 ou 11 dígitos).");

            // RG não pode se repetir
            var db = await CDatabase.GetConexao();
            int repetido = await db.Table<CCliente>()
                .Where(x => x.RG == c.RG && x.CodigoCliente != c.CodigoCliente)
                .CountAsync();

            if (repetido > 0)
                throw new CValidacaoException("Já existe um cliente cadastrado com esse RG.");
        }

        private async Task<CCliente> GarantirExiste(int codigo)
        {
            if (codigo <= 0)
                throw new CValidacaoException("Código do cliente inválido.");

            var db = await CDatabase.GetConexao();
            var c = await db.FindAsync<CCliente>(codigo);

            if (c == null)
                throw new CValidacaoException($"Cliente {codigo} não encontrado.");

            return c;
        }

        // ---------------- CRUD ----------------

        // CREATE
        public async Task<int> InsertCliente(CCliente c)
        {
            c.CodigoCliente = 0;
            await Validar(c);

            var db = await CDatabase.GetConexao();
            return await db.InsertAsync(c);
        }

        // UPDATE
        public async Task<int> UpdateCliente(CCliente c)
        {
            await GarantirExiste(c.CodigoCliente);
            await Validar(c);

            var db = await CDatabase.GetConexao();
            return await db.UpdateAsync(c);
        }

        // DELETE
        public async Task<int> DeleteCliente(int codigo)
        {
            await GarantirExiste(codigo);

            var db = await CDatabase.GetConexao();

            // Integridade referencial: não exclui cliente que possui compras
            int compras = await db.Table<CCompra>()
                .Where(x => x.CodigoCliente == codigo)
                .CountAsync();

            if (compras > 0)
                throw new CValidacaoException(
                    $"Não é possível excluir: o cliente possui {compras} compra(s) registrada(s).");

            return await db.DeleteAsync<CCliente>(codigo);
        }

        // READ - todos
        public async Task<List<CCliente>> GetClientes()
        {
            var db = await CDatabase.GetConexao();
            return await db.Table<CCliente>().OrderBy(x => x.Nome).ToListAsync();
        }

        // READ - por código
        public async Task<CCliente?> GetCliente(int codigo)
        {
            if (codigo <= 0)
                return null;

            var db = await CDatabase.GetConexao();
            return await db.FindAsync<CCliente>(codigo);
        }

        // READ - busca por nome (SearchBar)
        public async Task<List<CCliente>> ConsultarNome(string? texto)
        {
            var db = await CDatabase.GetConexao();
            texto = (texto ?? string.Empty).Trim();

            if (texto.Length == 0)
                return await GetClientes();

            // Consulta parametrizada (evita SQL Injection) e sem diferenciar maiúsculas/minúsculas
            return await db.QueryAsync<CCliente>(
                "SELECT * FROM Cliente WHERE Nome LIKE ? ORDER BY Nome",
                $"%{texto}%");
        }
    }
}
