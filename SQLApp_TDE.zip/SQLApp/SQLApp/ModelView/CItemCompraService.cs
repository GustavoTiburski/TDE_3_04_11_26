using SQLiteNetExtensionsAsync.Extensions;
using SQLApp.Model;

namespace SQLApp.ModelView
{
    // Os itens mexem no estoque e no total da compra, por isso
    // todas as operações rodam dentro de uma transação.
    public class CItemCompraService
    {
        // CREATE - adiciona um produto à compra.
        // Se o produto já estiver na compra, soma a quantidade.
        public async Task InsertItem(int codigoCompra, int codigoProduto, int quantidade)
        {
            var db = await CDatabase.GetConexao();

            await db.RunInTransactionAsync(conn =>
            {
                // Validações
                if (conn.Find<CCompra>(codigoCompra) == null)
                    throw new CValidacaoException("Selecione ou cadastre uma compra antes de adicionar itens.");

                var produto = conn.Find<CProduto>(codigoProduto);
                if (produto == null)
                    throw new CValidacaoException("Selecione um produto válido.");

                if (quantidade <= 0)
                    throw new CValidacaoException("A quantidade deve ser maior que zero.");

                if (quantidade > produto.QtdEstoque)
                    throw new CValidacaoException(
                        $"Estoque insuficiente para {produto.NomeProduto}. Disponível: {produto.QtdEstoque}.");

                var existente = conn.Table<CItemCompra>()
                    .Where(x => x.CodigoCompra == codigoCompra && x.CodigoProduto == codigoProduto)
                    .FirstOrDefault();

                if (existente == null)
                {
                    conn.Insert(new CItemCompra
                    {
                        CodigoCompra = codigoCompra,
                        CodigoProduto = codigoProduto,
                        Quantidade = quantidade,
                        ValorParcial = quantidade * produto.Preco
                    });
                }
                else
                {
                    // Mantém o preço unitário original do item
                    decimal unitario = existente.PrecoUnitario;
                    existente.Quantidade += quantidade;
                    existente.ValorParcial = existente.Quantidade * unitario;
                    conn.Update(existente);
                }

                // Baixa no estoque
                produto.QtdEstoque -= quantidade;
                conn.Update(produto);

                CCompraService.RecalcularTotal(conn, codigoCompra);
            });
        }

        // UPDATE - altera a quantidade de um item e ajusta o estoque pela diferença
        public async Task UpdateItem(int codigoItem, int novaQuantidade)
        {
            var db = await CDatabase.GetConexao();

            await db.RunInTransactionAsync(conn =>
            {
                var item = conn.Find<CItemCompra>(codigoItem);
                if (item == null)
                    throw new CValidacaoException("Selecione um item da compra para alterar.");

                if (novaQuantidade <= 0)
                    throw new CValidacaoException("A quantidade deve ser maior que zero. Para tirar o item, use Remover.");

                var produto = conn.Find<CProduto>(item.CodigoProduto);
                if (produto == null)
                    throw new CValidacaoException("O produto deste item não existe mais.");

                int diferenca = novaQuantidade - item.Quantidade;

                if (diferenca > produto.QtdEstoque)
                    throw new CValidacaoException(
                        $"Estoque insuficiente para {produto.NomeProduto}. Disponível: {produto.QtdEstoque}.");

                decimal unitario = item.PrecoUnitario;
                item.Quantidade = novaQuantidade;
                item.ValorParcial = novaQuantidade * unitario;
                conn.Update(item);

                produto.QtdEstoque -= diferenca;
                conn.Update(produto);

                CCompraService.RecalcularTotal(conn, item.CodigoCompra);
            });
        }

        // DELETE - remove o item e devolve a quantidade ao estoque
        public async Task DeleteItem(int codigoItem)
        {
            var db = await CDatabase.GetConexao();

            await db.RunInTransactionAsync(conn =>
            {
                var item = conn.Find<CItemCompra>(codigoItem);
                if (item == null)
                    throw new CValidacaoException("Selecione um item da compra para remover.");

                var produto = conn.Find<CProduto>(item.CodigoProduto);
                if (produto != null)
                {
                    produto.QtdEstoque += item.Quantidade;
                    conn.Update(produto);
                }

                conn.Delete<CItemCompra>(codigoItem);

                CCompraService.RecalcularTotal(conn, item.CodigoCompra);
            });
        }

        // READ - itens de uma compra, já com o produto carregado
        public async Task<List<CItemCompra>> GetItens(int codigoCompra)
        {
            if (codigoCompra <= 0)
                return new List<CItemCompra>();

            var db = await CDatabase.GetConexao();
            return await db.GetAllWithChildrenAsync<CItemCompra>(x => x.CodigoCompra == codigoCompra);
        }
    }
}
