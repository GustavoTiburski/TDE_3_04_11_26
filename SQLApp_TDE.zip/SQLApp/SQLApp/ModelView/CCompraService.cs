using SQLite;
using SQLiteNetExtensionsAsync.Extensions;
using SQLApp.Model;

namespace SQLApp.ModelView
{
    public class CCompraService
    {
        // ---------------- VALIDAÇÕES (back-end) ----------------

        private static void Validar(SQLiteConnection conn, CCompra c)
        {
            if (c == null)
                throw new CValidacaoException("Compra inválida.");

            if (c.CodigoCliente <= 0)
                throw new CValidacaoException("Selecione o cliente da compra.");

            if (conn.Find<CCliente>(c.CodigoCliente) == null)
                throw new CValidacaoException("O cliente informado não existe.");

            if (c.DataCompra.Date > DateTime.Today)
                throw new CValidacaoException("A data da compra não pode ser uma data futura.");

            if (c.DataCompra.Date < new DateTime(2000, 1, 1))
                throw new CValidacaoException("Data da compra inválida.");
        }

        // Recalcula o Valor Total da compra somando os valores parciais dos itens
        internal static void RecalcularTotal(SQLiteConnection conn, int codigoCompra)
        {
            var compra = conn.Find<CCompra>(codigoCompra);
            if (compra == null)
                return;

            compra.ValorTotal = conn.Table<CItemCompra>()
                .Where(x => x.CodigoCompra == codigoCompra)
                .ToList()
                .Sum(x => x.ValorParcial);

            conn.Update(compra);
        }

        // ---------------- CRUD ----------------

        // CREATE - cria a compra (cabeçalho). Os itens são adicionados depois.
        public async Task<int> InsertCompra(CCompra c)
        {
            c.CodigoCompra = 0;
            c.ValorTotal = 0;
            c.DataCompra = c.DataCompra.Date;

            var db = await CDatabase.GetConexao();
            await db.RunInTransactionAsync(conn =>
            {
                Validar(conn, c);
                conn.Insert(c);
            });

            return c.CodigoCompra;
        }

        // UPDATE - altera cliente e/ou data. O total continua vindo dos itens.
        public async Task<int> UpdateCompra(CCompra c)
        {
            var db = await CDatabase.GetConexao();
            int linhas = 0;

            await db.RunInTransactionAsync(conn =>
            {
                var atual = conn.Find<CCompra>(c.CodigoCompra);
                if (atual == null)
                    throw new CValidacaoException("Compra não encontrada.");

                c.DataCompra = c.DataCompra.Date;
                Validar(conn, c);

                atual.CodigoCliente = c.CodigoCliente;
                atual.DataCompra = c.DataCompra;
                linhas = conn.Update(atual);

                RecalcularTotal(conn, atual.CodigoCompra);
            });

            return linhas;
        }

        // DELETE - exclui a compra, seus itens e devolve os produtos ao estoque
        public async Task<int> DeleteCompra(int codigo)
        {
            var db = await CDatabase.GetConexao();
            int linhas = 0;

            await db.RunInTransactionAsync(conn =>
            {
                if (conn.Find<CCompra>(codigo) == null)
                    throw new CValidacaoException("Compra não encontrada.");

                var itens = conn.Table<CItemCompra>()
                    .Where(x => x.CodigoCompra == codigo)
                    .ToList();

                foreach (var item in itens)
                {
                    var produto = conn.Find<CProduto>(item.CodigoProduto);
                    if (produto != null)
                    {
                        produto.QtdEstoque += item.Quantidade;
                        conn.Update(produto);
                    }
                    conn.Delete<CItemCompra>(item.CodigoItem);
                }

                linhas = conn.Delete<CCompra>(codigo);
            });

            return linhas;
        }

        // READ - todas as compras, já com o cliente carregado
        public async Task<List<CCompra>> GetCompras()
        {
            var db = await CDatabase.GetConexao();
            var lista = await db.GetAllWithChildrenAsync<CCompra>();
            return lista.OrderByDescending(x => x.DataCompra)
                        .ThenByDescending(x => x.CodigoCompra)
                        .ToList();
        }

        // READ - por código, com cliente e itens
        public async Task<CCompra?> GetCompra(int codigo)
        {
            if (codigo <= 0)
                return null;

            var db = await CDatabase.GetConexao();
            if (await db.FindAsync<CCompra>(codigo) == null)
                return null;

            return await db.GetWithChildrenAsync<CCompra>(codigo);
        }

        // READ - busca pelo nome do cliente (SearchBar)
        public async Task<List<CCompra>> ConsultarCliente(string? texto)
        {
            var lista = await GetCompras();
            texto = (texto ?? string.Empty).Trim();

            if (texto.Length == 0)
                return lista;

            return lista
                .Where(x => x.NomeCliente.Contains(texto, StringComparison.OrdinalIgnoreCase))
                .ToList();
        }
    }
}
