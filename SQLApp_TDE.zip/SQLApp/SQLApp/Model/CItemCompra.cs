using SQLite;
using SQLiteNetExtensions.Attributes;

namespace SQLApp.Model
{
    // Tabela ItemCompra
    // O sqlite-net não suporta chave primária composta, então CodigoItem é a PK
    // e o par (CodigoCompra, CodigoProduto) recebe um índice único.
    [Table("ItemCompra")]
    public class CItemCompra
    {
        [PrimaryKey, AutoIncrement]
        public int CodigoItem { get; set; }

        // Chave estrangeira para Produto
        [ForeignKey(typeof(CProduto)), Indexed(Name = "UX_ItemCompra", Order = 2, Unique = true)]
        public int CodigoProduto { get; set; }

        // Chave estrangeira para Compra
        [ForeignKey(typeof(CCompra)), Indexed(Name = "UX_ItemCompra", Order = 1, Unique = true)]
        public int CodigoCompra { get; set; }

        public int Quantidade { get; set; }

        // Quantidade x preço unitário do produto no momento da compra
        public decimal ValorParcial { get; set; }

        [ManyToOne]
        public CProduto? Produto { get; set; }

        [ManyToOne]
        public CCompra? Compra { get; set; }

        // Campos apenas para exibição na tela
        [Ignore]
        public string NomeProduto => Produto?.NomeProduto ?? string.Empty;

        [Ignore]
        public decimal PrecoUnitario => Quantidade > 0 ? ValorParcial / Quantidade : 0;
    }
}
