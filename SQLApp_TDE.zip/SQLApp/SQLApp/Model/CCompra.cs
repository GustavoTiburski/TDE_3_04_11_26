using SQLite;
using SQLiteNetExtensions.Attributes;

namespace SQLApp.Model
{
    // Tabela Compra
    [Table("Compra")]
    public class CCompra
    {
        [PrimaryKey, AutoIncrement]
        public int CodigoCompra { get; set; }

        public DateTime DataCompra { get; set; } = DateTime.Today;

        // Calculado automaticamente pela soma dos itens
        public decimal ValorTotal { get; set; }

        // Chave estrangeira para Cliente
        [ForeignKey(typeof(CCliente)), Indexed]
        public int CodigoCliente { get; set; }

        // Relacionamento N:1 -> cada compra pertence a um cliente
        [ManyToOne]
        public CCliente? Cliente { get; set; }

        // Relacionamento 1:N -> uma compra possui vários itens
        [OneToMany]
        public List<CItemCompra> Itens { get; set; } = new List<CItemCompra>();

        // Campos apenas para exibição na tela
        [Ignore]
        public string NomeCliente => Cliente?.Nome ?? string.Empty;

        [Ignore]
        public string DataFormatada => DataCompra.ToString("dd/MM/yyyy");
    }
}
