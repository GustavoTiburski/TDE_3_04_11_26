using SQLite;
using SQLiteNetExtensions.Attributes;

namespace SQLApp.Model
{
    // Tabela Produto
    [Table("Produto")]
    public class CProduto
    {
        [PrimaryKey, AutoIncrement]
        public int CodigoProduto { get; set; }

        [MaxLength(50), NotNull]
        public string NomeProduto { get; set; } = string.Empty;

        [MaxLength(50), NotNull]
        public string Tipo { get; set; } = string.Empty;

        // MONEY -> decimal
        public decimal Preco { get; set; }

        public int QtdEstoque { get; set; }

        // Relacionamento 1:N -> um produto aparece em vários itens de compra
        [OneToMany]
        public List<CItemCompra> Itens { get; set; } = new List<CItemCompra>();

        // Usado para exibir nos Pickers
        [Ignore]
        public string Descricao => $"{NomeProduto} - {Preco:C} (estoque: {QtdEstoque})";
    }
}
