using SQLite;
using SQLiteNetExtensions.Attributes;

namespace SQLApp.Model
{
    // Tabela Cliente
    [Table("Cliente")]
    public class CCliente
    {
        [PrimaryKey, AutoIncrement]
        public int CodigoCliente { get; set; }

        [MaxLength(50), NotNull]
        public string Nome { get; set; } = string.Empty;

        // RG com 10 dígitos não cabe em INT (máx. 2.147.483.647), por isso long
        [Unique]
        public long RG { get; set; }

        [MaxLength(14)]
        public string Telefone { get; set; } = string.Empty;

        // Relacionamento 1:N -> um cliente possui várias compras
        [OneToMany]
        public List<CCompra> Compras { get; set; } = new List<CCompra>();
    }
}
