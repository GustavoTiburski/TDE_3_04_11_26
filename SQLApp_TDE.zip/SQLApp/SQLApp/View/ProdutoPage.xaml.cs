using SQLApp.Model;
using SQLApp.ModelView;
using System.Collections.ObjectModel;
using System.Globalization;

namespace SQLApp.View;

public partial class ProdutoPage : ContentPage
{
    // Instância para tratamento da tabela Produto
    CProdutoService _produtoService = new CProdutoService();

    // Lista para preencher o CollectionView
    ObservableCollection<CProduto> _lista = new ObservableCollection<CProduto>();

    public ProdutoPage()
    {
        InitializeComponent();
        lvLista.ItemsSource = _lista;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await CarregarLista(sbBusca.Text);
    }

    private async Task CarregarLista(string? filtro = null)
    {
        try
        {
            var aux = await _produtoService.ConsultarNome(filtro);
            _lista.Clear();
            aux.ForEach(i => _lista.Add(i));
        }
        catch (Exception ex)
        {
            await DisplayAlertAsync("Erro", ex.Message, "OK");
        }
    }

    // Aceita "10,50" ou "10.50"
    private static bool LerDecimal(string? texto, out decimal valor)
    {
        texto = (texto ?? string.Empty).Replace("R$", "").Replace(" ", "").Trim();

        // "1.234,56" -> remove o separador de milhar
        if (texto.Contains(',') && texto.Contains('.'))
            texto = texto.Replace(".", "");

        texto = texto.Replace(',', '.');

        return decimal.TryParse(texto, NumberStyles.Number, CultureInfo.InvariantCulture, out valor);
    }

    // Monta o objeto a partir do formulário (conversão de tipos).
    // As regras de negócio ficam no Service.
    private async Task<CProduto?> LerFormulario(bool exigeCodigo)
    {
        int codigo = 0;
        if (exigeCodigo && !int.TryParse(txCodigo.Text, out codigo))
        {
            await DisplayAlertAsync("Erro", "Selecione um produto.", "OK");
            return null;
        }

        if (!LerDecimal(txPreco.Text, out decimal preco))
        {
            await DisplayAlertAsync("Erro", "Informe um preço válido. Ex: 10,50", "OK");
            return null;
        }

        if (!int.TryParse(txEstoque.Text?.Trim(), out int estoque))
        {
            await DisplayAlertAsync("Erro", "Informe a quantidade em estoque (número inteiro).", "OK");
            return null;
        }

        return new CProduto
        {
            CodigoProduto = codigo,
            NomeProduto = txNome.Text ?? string.Empty,
            Tipo = txTipo.Text ?? string.Empty,
            Preco = preco,
            QtdEstoque = estoque
        };
    }

    private void PreencherFormulario(CProduto p)
    {
        txCodigo.Text = p.CodigoProduto.ToString();
        txNome.Text = p.NomeProduto;
        txTipo.Text = p.Tipo;
        txPreco.Text = p.Preco.ToString("0.00");
        txEstoque.Text = p.QtdEstoque.ToString();
    }

    private async void btConsultar_Clicked(object sender, EventArgs e)
    {
        if (!int.TryParse(txCodigo.Text, out int codigo))
        {
            await DisplayAlertAsync("Erro", "Informe um código válido!", "OK");
            return;
        }

        var p = await _produtoService.GetProduto(codigo);
        if (p == null)
        {
            await DisplayAlertAsync("Erro", "Produto não encontrado!", "OK");
            return;
        }

        PreencherFormulario(p);
    }

    private void btLimpar_Clicked(object sender, EventArgs e)
    {
        txCodigo.Text = string.Empty;
        txNome.Text = string.Empty;
        txTipo.Text = string.Empty;
        txPreco.Text = string.Empty;
        txEstoque.Text = string.Empty;
        lvLista.SelectedItem = null;
        txNome.Focus();
    }

    private async void btIncluir_Clicked(object sender, EventArgs e)
    {
        try
        {
            var p = await LerFormulario(false);
            if (p == null)
                return;

            await _produtoService.InsertProduto(p);
            await DisplayAlertAsync("Sucesso", $"Produto cadastrado com código {p.CodigoProduto}!", "OK");
            btLimpar_Clicked(sender, e);
            await CarregarLista();
        }
        catch (Exception ex)
        {
            await DisplayAlertAsync("Erro", ex.Message, "OK");
        }
    }

    private async void btAlterar_Clicked(object sender, EventArgs e)
    {
        try
        {
            var p = await LerFormulario(true);
            if (p == null)
                return;

            await _produtoService.UpdateProduto(p);
            await DisplayAlertAsync("Sucesso", "Produto alterado com sucesso!", "OK");
            btLimpar_Clicked(sender, e);
            await CarregarLista();
        }
        catch (Exception ex)
        {
            await DisplayAlertAsync("Erro", ex.Message, "OK");
        }
    }

    private async void btExcluir_Clicked(object sender, EventArgs e)
    {
        try
        {
            if (!int.TryParse(txCodigo.Text, out int codigo))
            {
                await DisplayAlertAsync("Erro", "Selecione um produto para excluir.", "OK");
                return;
            }

            bool ok = await DisplayAlertAsync("Confirmação",
                $"Deseja realmente excluir o produto {codigo}?", "Sim", "Não");
            if (!ok)
                return;

            await _produtoService.DeleteProduto(codigo);
            await DisplayAlertAsync("Sucesso", "Produto excluído com sucesso!", "OK");
            btLimpar_Clicked(sender, e);
            await CarregarLista();
        }
        catch (Exception ex)
        {
            await DisplayAlertAsync("Erro", ex.Message, "OK");
        }
    }

    private async void sbBusca_TextChanged(object sender, TextChangedEventArgs e)
    {
        await CarregarLista(e.NewTextValue);
    }

    private async void rvLista_Refreshing(object sender, EventArgs e)
    {
        await CarregarLista(sbBusca.Text);
        rvLista.IsRefreshing = false;
    }

    private void lvLista_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (e.CurrentSelection.FirstOrDefault() is CProduto p)
        {
            PreencherFormulario(p);
            txNome.Focus();
            ((CollectionView)sender).SelectedItem = null;
        }
    }
}
