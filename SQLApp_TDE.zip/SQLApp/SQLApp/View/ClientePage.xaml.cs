using SQLApp.Model;
using SQLApp.ModelView;
using System.Collections.ObjectModel;

namespace SQLApp.View;

public partial class ClientePage : ContentPage
{
    // Instância para tratamento da tabela Cliente
    CClienteService _clienteService = new CClienteService();

    // Lista para preencher o CollectionView
    ObservableCollection<CCliente> _lista = new ObservableCollection<CCliente>();

    public ClientePage()
    {
        InitializeComponent();
        lvLista.ItemsSource = _lista;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await CarregarLista();
    }

    private async Task CarregarLista(string? filtro = null)
    {
        try
        {
            var aux = await _clienteService.ConsultarNome(filtro);
            _lista.Clear();
            aux.ForEach(i => _lista.Add(i));
        }
        catch (Exception ex)
        {
            await DisplayAlertAsync("Erro", ex.Message, "OK");
        }
    }

    // Monta o objeto a partir do formulário
    private CCliente? LerFormulario(bool exigeCodigo)
    {
        int codigo = 0;
        if (exigeCodigo && !int.TryParse(txCodigo.Text, out codigo))
            return null;

        // RG vazio ou inválido vira 0 e é barrado na validação do Service
        long.TryParse(txRG.Text?.Trim(), out long rg);

        return new CCliente
        {
            CodigoCliente = codigo,
            Nome = txNome.Text ?? string.Empty,
            RG = rg,
            Telefone = txTelefone.Text ?? string.Empty
        };
    }

    private void PreencherFormulario(CCliente c)
    {
        txCodigo.Text = c.CodigoCliente.ToString();
        txNome.Text = c.Nome;
        txRG.Text = c.RG.ToString();
        txTelefone.Text = c.Telefone;
    }

    private async void btConsultar_Clicked(object sender, EventArgs e)
    {
        if (!int.TryParse(txCodigo.Text, out int codigo))
        {
            await DisplayAlertAsync("Erro", "Informe um código válido!", "OK");
            return;
        }

        var c = await _clienteService.GetCliente(codigo);
        if (c == null)
        {
            await DisplayAlertAsync("Erro", "Cliente não encontrado!", "OK");
            return;
        }

        PreencherFormulario(c);
    }

    private void btLimpar_Clicked(object sender, EventArgs e)
    {
        txCodigo.Text = string.Empty;
        txNome.Text = string.Empty;
        txRG.Text = string.Empty;
        txTelefone.Text = string.Empty;
        lvLista.SelectedItem = null;
        txNome.Focus();
    }

    private async void btIncluir_Clicked(object sender, EventArgs e)
    {
        try
        {
            var c = LerFormulario(false)!;
            await _clienteService.InsertCliente(c);
            await DisplayAlertAsync("Sucesso", $"Cliente cadastrado com código {c.CodigoCliente}!", "OK");
            btLimpar_Clicked(sender, e);
            await CarregarLista();
        }
        catch (Exception ex)
        {
            await DisplayAlertAsync("Erro", ex.Message, "OK");
        }
    }

    private async void btAlterar_Clicked(object sender, EventArgs e)
    {
        try
        {
            var c = LerFormulario(true);
            if (c == null)
            {
                await DisplayAlertAsync("Erro", "Selecione um cliente para alterar.", "OK");
                return;
            }

            await _clienteService.UpdateCliente(c);
            await DisplayAlertAsync("Sucesso", "Cliente alterado com sucesso!", "OK");
            btLimpar_Clicked(sender, e);
            await CarregarLista();
        }
        catch (Exception ex)
        {
            await DisplayAlertAsync("Erro", ex.Message, "OK");
        }
    }

    private async void btExcluir_Clicked(object sender, EventArgs e)
    {
        try
        {
            if (!int.TryParse(txCodigo.Text, out int codigo))
            {
                await DisplayAlertAsync("Erro", "Selecione um cliente para excluir.", "OK");
                return;
            }

            bool ok = await DisplayAlertAsync("Confirmação",
                $"Deseja realmente excluir o cliente {codigo}?", "Sim", "Não");
            if (!ok)
                return;

            await _clienteService.DeleteCliente(codigo);
            await DisplayAlertAsync("Sucesso", "Cliente excluído com sucesso!", "OK");
            btLimpar_Clicked(sender, e);
            await CarregarLista();
        }
        catch (Exception ex)
        {
            await DisplayAlertAsync("Erro", ex.Message, "OK");
        }
    }

    private async void sbBusca_TextChanged(object sender, TextChangedEventArgs e)
    {
        await CarregarLista(e.NewTextValue);
    }

    private async void rvLista_Refreshing(object sender, EventArgs e)
    {
        await CarregarLista(sbBusca.Text);
        rvLista.IsRefreshing = false;
    }

    private void lvLista_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (e.CurrentSelection.FirstOrDefault() is CCliente c)
        {
            PreencherFormulario(c);
            txNome.Focus();
            ((CollectionView)sender).SelectedItem = null;
        }
    }
}
