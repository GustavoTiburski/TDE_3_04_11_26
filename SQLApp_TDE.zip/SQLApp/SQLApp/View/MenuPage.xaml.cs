namespace SQLApp.View;

public partial class MenuPage : ContentPage
{
    public MenuPage()
    {
        InitializeComponent();
    }

    private async void btClientes_Clicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("//Clientes");
    }

    private async void btProdutos_Clicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("//Produtos");
    }

    private async void btCompras_Clicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("//Compras");
    }
}
