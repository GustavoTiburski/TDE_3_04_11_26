using SQLApp.Model;
using SQLApp.ModelView;
using System.Collections.ObjectModel;

namespace SQLApp.View;

public partial class CompraPage : ContentPage
{
    // Services das tabelas usadas nesta tela
    CCompraService _compraService = new CCompraService();
    CItemCompraService _itemService = new CItemCompraService();
    CClienteService _clienteService = new CClienteService();
    CProdutoService _produtoService = new CProdutoService();

    // Listas da tela
    ObservableCollection<CCompra> _compras = new ObservableCollection<CCompra>();
    ObservableCollection<CItemCompra> _itens = new ObservableCollection<CItemCompra>();
    List<CCliente> _clientes = new List<CCliente>();
    List<CProduto> _produtos = new List<CProduto>();

    // Compra e item que estão selecionados no momento
    int _codigoCompra = 0;
    int _codigoItem = 0;

    public CompraPage()
    {
        InitializeComponent();

        lvCompras.ItemsSource = _compras;
        lvItens.ItemsSource = _itens;

        pkCliente.ItemDisplayBinding = new Binding(nameof(CCliente.Nome));
        pkProduto.ItemDisplayBinding = new Binding(nameof(CProduto.Descricao));

        dpData.MaximumDate = DateTime.Today;
        dpData.Date = DateTime.Today;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();

        // Recarrega clientes e produtos, pois podem ter mudado nas outras telas
        await CarregarClientes();
        await CarregarProdutos();
        await CarregarCompras(sbBusca.Text);

        if (_codigoCompra > 0)
            await CarregarCompra(_codigoCompra);
    }

    // ---------------- CARGAS ----------------

    private async Task CarregarClientes()
    {
        try
        {
            int selecionado = (pkCliente.SelectedItem as CCliente)?.CodigoCliente ?? 0;
            _clientes = await _clienteService.GetClientes();
            pkCliente.ItemsSource = _clientes;
            SelecionarCliente(selecionado);
        }
        catch (Exception ex)
        {
            await DisplayAlertAsync("Erro", ex.Message, "OK");
        }
    }

    private async Task CarregarProdutos()
    {
        try
        {
            int selecionado = (pkProduto.SelectedItem as CProduto)?.CodigoProduto ?? 0;
            _produtos = await _produtoService.GetProdutos();
            pkProduto.ItemsSource = _produtos;
            SelecionarProduto(selecionado);
        }
        catch (Exception ex)
        {
            await DisplayAlertAsync("Erro", ex.Message, "OK");
        }
    }

    private async Task CarregarCompras(string? filtro = null)
    {
        try
        {
            var aux = await _compraService.ConsultarCliente(filtro);
            _compras.Clear();
            aux.ForEach(i => _compras.Add(i));
        }
        catch (Exception ex)
        {
            await DisplayAlertAsync("Erro", ex.Message, "OK");
        }
    }

    // Carrega uma compra no formulário junto com os seus itens
    private async Task<bool> CarregarCompra(int codigo)
    {
        var c = await _compraService.GetCompra(codigo);
        if (c == null)
            return false;

        _codigoCompra = c.CodigoCompra;
        txCodigo.Text = c.CodigoCompra.ToString();
        SelecionarCliente(c.CodigoCliente);
        dpData.Date = c.DataCompra;
        lbTotal.Text = $"Valor Total: {c.ValorTotal:C}";

        await CarregarItens();
        return true;
    }

    private async Task CarregarItens()
    {
        var aux = await _itemService.GetItens(_codigoCompra);
        _itens.Clear();
        aux.ForEach(i => _itens.Add(i));
        LimparItem();
    }

    // Depois de mexer em itens: atualiza total, estoque dos produtos e lista de compras
    private async Task AtualizarAposItem()
    {
        await CarregarProdutos();
        await CarregarCompra(_codigoCompra);
        await CarregarCompras(sbBusca.Text);
    }

    private void SelecionarCliente(int codigo)
    {
        pkCliente.SelectedIndex = _clientes.FindIndex(x => x.CodigoCliente == codigo);
    }

    private void SelecionarProduto(int codigo)
    {
        pkProduto.SelectedIndex = _produtos.FindIndex(x => x.CodigoProduto == codigo);
    }

    private DateTime DataSelecionada()
    {
        return dpData.Date is DateTime d ? d : DateTime.Today;
    }

    // ---------------- COMPRA ----------------

    private async void btConsultar_Clicked(object sender, EventArgs e)
    {
        if (!int.TryParse(txCodigo.Text, out int codigo))
        {
            await DisplayAlertAsync("Erro", "Informe um código válido!", "OK");
            return;
        }

        if (!await CarregarCompra(codigo))
            await DisplayAlertAsync("Erro", "Compra não encontrada!", "OK");
    }

    private void btLimpar_Clicked(object sender, EventArgs e)
    {
        _codigoCompra = 0;
        txCodigo.Text = string.Empty;
        pkCliente.SelectedIndex = -1;
        dpData.Date = DateTime.Today;
        lbTotal.Text = $"Valor Total: {0m:C}";
        _itens.Clear();
        LimparItem();
        lvCompras.SelectedItem = null;
    }

    private async void btIncluir_Clicked(object sender, EventArgs e)
    {
        try
        {
            var c = new CCompra
            {
                CodigoCliente = (pkCliente.SelectedItem as CCliente)?.CodigoCliente ?? 0,
                DataCompra = DataSelecionada()
            };

            int codigo = await _compraService.InsertCompra(c);
            await CarregarCompra(codigo);
            await CarregarCompras(sbBusca.Text);

            await DisplayAlertAsync("Sucesso",
                $"Compra {codigo} cadastrada! Agora adicione os itens.", "OK");
        }
        catch (Exception ex)
        {
            await DisplayAlertAsync("Erro", ex.Message, "OK");
        }
    }

    private async void btAlterar_Clicked(object sender, EventArgs e)
    {
        try
        {
            if (_codigoCompra <= 0)
            {
                await DisplayAlertAsync("Erro", "Selecione uma compra para alterar.", "OK");
                return;
            }

            var c = new CCompra
            {
                CodigoCompra = _codigoCompra,
                CodigoCliente = (pkCliente.SelectedItem as CCliente)?.CodigoCliente ?? 0,
                DataCompra = DataSelecionada()
            };

            await _compraService.UpdateCompra(c);
            await CarregarCompra(_codigoCompra);
            await CarregarCompras(sbBusca.Text);
            await DisplayAlertAsync("Sucesso", "Compra alterada com sucesso!", "OK");
        }
        catch (Exception ex)
        {
            await DisplayAlertAsync("Erro", ex.Message, "OK");
        }
    }

    private async void btExcluir_Clicked(object sender, EventArgs e)
    {
        try
        {
            if (_codigoCompra <= 0)
            {
                await DisplayAlertAsync("Erro", "Selecione uma compra para excluir.", "OK");
                return;
            }

            bool ok = await DisplayAlertAsync("Confirmação",
                $"Excluir a compra {_codigoCompra}? Os itens serão removidos e os produtos voltarão ao estoque.",
                "Sim", "Não");
            if (!ok)
                return;

            await _compraService.DeleteCompra(_codigoCompra);
            btLimpar_Clicked(sender, e);
            await CarregarProdutos();
            await CarregarCompras(sbBusca.Text);
            await DisplayAlertAsync("Sucesso", "Compra excluída com sucesso!", "OK");
        }
        catch (Exception ex)
        {
            await DisplayAlertAsync("Erro", ex.Message, "OK");
        }
    }

    // ---------------- ITENS ----------------

    private void LimparItem()
    {
        _codigoItem = 0;
        txQuantidade.Text = string.Empty;
        pkProduto.SelectedIndex = -1;
        pkProduto.IsEnabled = true;
        lbItemSelecionado.Text = "Nenhum item selecionado";
        lvItens.SelectedItem = null;
    }

    private async void btAdicionarItem_Clicked(object sender, EventArgs e)
    {
        try
        {
            if (_codigoItem > 0)
            {
                // Estava com um item selecionado: volta para o modo "novo item"
                LimparItem();
                await DisplayAlertAsync("Aviso", "Escolha o produto e a quantidade do novo item.", "OK");
                return;
            }

            if (!int.TryParse(txQuantidade.Text?.Trim(), out int qtd))
            {
                await DisplayAlertAsync("Erro", "Informe a quantidade (número inteiro).", "OK");
                return;
            }

            int codigoProduto = (pkProduto.SelectedItem as CProduto)?.CodigoProduto ?? 0;

            await _itemService.InsertItem(_codigoCompra, codigoProduto, qtd);
            await AtualizarAposItem();
        }
        catch (Exception ex)
        {
            await DisplayAlertAsync("Erro", ex.Message, "OK");
        }
    }

    private async void btAlterarItem_Clicked(object sender, EventArgs e)
    {
        try
        {
            if (_codigoItem <= 0)
            {
                await DisplayAlertAsync("Erro", "Selecione um item na lista para alterar.", "OK");
                return;
            }

            if (!int.TryParse(txQuantidade.Text?.Trim(), out int qtd))
            {
                await DisplayAlertAsync("Erro", "Informe a quantidade (número inteiro).", "OK");
                return;
            }

            await _itemService.UpdateItem(_codigoItem, qtd);
            await AtualizarAposItem();
        }
        catch (Exception ex)
        {
            await DisplayAlertAsync("Erro", ex.Message, "OK");
        }
    }

    private async void btRemoverItem_Clicked(object sender, EventArgs e)
    {
        try
        {
            if (_codigoItem <= 0)
            {
                await DisplayAlertAsync("Erro", "Selecione um item na lista para remover.", "OK");
                return;
            }

            bool ok = await DisplayAlertAsync("Confirmação",
                "Remover este item? A quantidade volta para o estoque.", "Sim", "Não");
            if (!ok)
                return;

            await _itemService.DeleteItem(_codigoItem);
            await AtualizarAposItem();
        }
        catch (Exception ex)
        {
            await DisplayAlertAsync("Erro", ex.Message, "OK");
        }
    }

    private void lvItens_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (e.CurrentSelection.FirstOrDefault() is CItemCompra item)
        {
            _codigoItem = item.CodigoItem;
            SelecionarProduto(item.CodigoProduto);
            pkProduto.IsEnabled = false; // no item só se altera a quantidade
            txQuantidade.Text = item.Quantidade.ToString();
            lbItemSelecionado.Text = $"Item {item.CodigoItem} selecionado: {item.NomeProduto}";
            txQuantidade.Focus();
        }
    }

    // ---------------- LISTA DE COMPRAS ----------------

    private async void sbBusca_TextChanged(object sender, TextChangedEventArgs e)
    {
        await CarregarCompras(e.NewTextValue);
    }

    private async void rvLista_Refreshing(object sender, EventArgs e)
    {
        await CarregarCompras(sbBusca.Text);
        rvLista.IsRefreshing = false;
    }

    private async void lvCompras_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (e.CurrentSelection.FirstOrDefault() is CCompra c)
        {
            ((CollectionView)sender).SelectedItem = null;
            await CarregarCompra(c.CodigoCompra);
        }
    }
}
