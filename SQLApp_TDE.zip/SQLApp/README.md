# SQLApp - TDE Banco de Dados Relacional com .NET MAUI

Aplicativo .NET MAUI com banco de dados SQLite (sqlite-net-pcl + SQLiteNetExtensions.Async), baseado no SQLApp desenvolvido em aula.

## Funcionalidades

- **Menu principal** com acesso a Cadastro de Clientes, Cadastro de Produtos e Compra (também pelo menu lateral)
- **CRUD completo** nas 4 tabelas: Cliente, Produto, Compra e ItemCompra
- **Validações no back-end** (classes Service da pasta `ModelView`) antes de acessar o banco
- Busca por nome (SearchBar), consulta por código e listas com seleção para edição

## Modelo

| Tabela | Campos |
|---|---|
| Cliente | CodigoCliente (PK), Nome, RG, Telefone |
| Produto | CodigoProduto (PK), NomeProduto, Tipo, Preco, QtdEstoque |
| Compra | CodigoCompra (PK), DataCompra, ValorTotal, CodigoCliente (FK) |
| ItemCompra | CodigoItem (PK), CodigoProduto (FK), CodigoCompra (FK), Quantidade, ValorParcial |

Observações de implementação:
- **RG** usa `long`, porque um RG de 10 dígitos não cabe em `int`.
- O sqlite-net não suporta chave primária composta, então em **ItemCompra** a PK é `CodigoItem` e o par (CodigoCompra, CodigoProduto) tem índice único.
- **MONEY** foi mapeado como `decimal`.

## Regras e validações

**Cliente**: nome obrigatório (3 a 50 caracteres); RG numérico, até 10 dígitos e único; telefone com DDD (10 ou 11 dígitos, até 14 caracteres). Não exclui cliente com compras.

**Produto**: nome e tipo obrigatórios (até 50); preço maior que zero com até 2 casas; estoque não negativo. Não exclui produto usado em alguma compra.

**Compra**: cliente obrigatório e existente; data não pode ser futura. O Valor Total é calculado pela soma dos itens. Ao excluir, os itens são removidos e os produtos voltam ao estoque.

**ItemCompra**: produto existente, quantidade maior que zero e disponível em estoque. Valor Parcial = quantidade x preço. Adicionar, alterar e remover itens atualiza o estoque e o total da compra (tudo em transação).

## Estrutura

```
SQLApp/
├── Model/        CCliente, CProduto, CCompra, CItemCompra
├── ModelView/    CDatabase + Services (CRUD e validações)
└── View/         MenuPage, ClientePage, ProdutoPage, CompraPage
```

## Como executar

Abrir `SQLApp.slnx` no Visual Studio 2026 com o workload .NET MAUI e rodar no emulador Android ou no Windows.
